package gbc.ca.comp3095teamcrackers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
Comp3095-Team-Crackers-Assignment-2
        Team Members:
        Safa Aru :     101331910
        Hakan Inel :   101213098
        Onur Korkmaz : 101303363
        Ahmet Buyukbas: 101304595
*/

@SpringBootApplication
public class Comp3095TeamCrackersApplication {

    public static void main(String[] args) {
        SpringApplication.run(Comp3095TeamCrackersApplication.class, args);
    }

}
