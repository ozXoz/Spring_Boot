package gbc.ca.comp3095teamcrackers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Comp3095TeamCrackersApplicationTests {

    @Test
    void contextLoads() {
    }

}
